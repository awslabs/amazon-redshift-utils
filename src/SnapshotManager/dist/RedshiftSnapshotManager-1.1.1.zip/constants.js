// TODO comments about what these are...
exports.snapPrefix = "rs-snapman";
exports.createdByName = "createdBy";
exports.createdByValue = "AWS Redshift Utils Snapshot Manager";
exports.createdAtName = "creationTimestamp";
exports.dateFormat = "YYYY-MM-DD-HHmmss";
exports.namespaceTagName = "scheduleNamespace";
exports.validTimeUnits = [ "minutes", "hours", "days", "months", "years" ];
exports.OK = 0;
exports.ERROR = -1;