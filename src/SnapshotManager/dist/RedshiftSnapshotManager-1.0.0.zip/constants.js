exports.snapPrefix = "rs-snapman";
exports.createdByName = "createdBy";
exports.createdByValue = "AWS Redshift Utils Snapshot Manager";
exports.createdAtName = "creationTimestamp";
exports.dateFormat = "YYYY-MM-DD-HHmmss";
exports. namespaceTagName = "scheduleNamespace";
exports.OK = 0;
exports.ERROR = -1;