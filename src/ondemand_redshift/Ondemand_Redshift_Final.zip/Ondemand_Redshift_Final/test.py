import boto3
import os
import botocore
import awscli
import random
import time
from boto3.s3.transfer import S3Transfer
from botocore.exceptions import ClientError
import awscli.customizations.datapipeline.translator as trans
import requests
import urllib.request
import json
import time

delete_time = input('Enter the deletion time')
delete_cron = 'cron(0 '+delete_time + ' * * ? *)'
print(delete_cron)

#sg-53da8518
#subnet-d8b818bf
