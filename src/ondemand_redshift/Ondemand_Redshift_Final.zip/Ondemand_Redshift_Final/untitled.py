   
import boto3
import os
import botocore
import awscli
import random
import time
from boto3.s3.transfer import S3Transfer
from botocore.exceptions import ClientError
import awscli.customizations.datapipeline.translator as trans
import requests
import json


lambda_client=boto3.client('lambda')
lambda_client.create_function(FunctionName='Redshift-ondemand-function',Runtime='python3.6',Role='arn:aws:iam::596049777126:role/ondemand-redshift-role-do-not-delete',Handler='Redshift-ondemand-function.lambda_handler',Code=dict(S3Bucket='ondemand-redshift-596049777126790-do-not-delete',S3Key='Redshift-ondemand-function.py.zip'),Timeout=300)
