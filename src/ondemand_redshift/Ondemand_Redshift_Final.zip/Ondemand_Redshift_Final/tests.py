import boto3
import os
import botocore
import awscli
from boto3.s3.transfer import S3Transfer
from botocore.exceptions import ClientError
import awscli.customizations.datapipeline.translator as trans
import random
import requests
import urllib.request
import json
from botocore.vendored import requests
#import urllib.request.urlretrieve
#import urllib2
iam= boto3.client('iam')
#iam.attach_role_policy(RoleName='ondemand-redshift-role-do-not-delete',PolicyArn='arn:aws:iam::aws:policy/CloudWatchEventsFullAccess')

event = boto3.client('events')
event.put_rule(Name='Ondemand-rule-trial', ScheduleExpression='rate(5 minutes)',State='ENABLED',RoleArn='arn:aws:iam::832461927199:role/ondemand-redshift-role-do-not-delete')

event = boto3.client('events')
lamb = boto3.client('lambda')
'''
rule_response= event.put_rule(Name='Ondemand-rule', ScheduleExpression='rate(5 minutes)')
rule_response1= rule_response['RuleArn']

lamb.add_permission(FunctionName='Ondemand-Redshift',StatementId='Ondemand_redshift',Action='lambda:InvokeFunction',Principal='events.amazonaws.com',SourceArn=rule_response1)

event.put_targets(Rule='Ondemand-rule',Targets=[
        {
            'Arn': 'arn:aws:lambda:us-east-1:832461927199:function:Ondemand-Redshift',
            'Id': 'myCloudWatchEventsTarget',
        }
    ]
)

event.put_events(
    Entries=[
        {
            'Detail': json.dumps({'key1': 'value1', 'key2': 'value2'}),
            'Resources': [
                'arn:aws:lambda:us-east-1:832461927199:function:Ondemand-Redshift',
            ]
        }
    ]
)
'''
response_ARN=lamb.get_function(FunctionName='Ondemand-Redshift')
response_ARN=(response_ARN['Configuration']['FunctionArn'])
print(response_ARN)
